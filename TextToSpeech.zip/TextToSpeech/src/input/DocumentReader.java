package input;

public interface DocumentReader {
	
	public String read();

}
