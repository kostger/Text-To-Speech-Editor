package output;

public interface DocumentWriter {
	
	public void write(String text);

}
