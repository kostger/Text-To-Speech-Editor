package model;

public interface TTS {
	
	public void play(String str);
	
	public void setVolume(int vol);
	
	public void setSpeechRate(int rate);
	
	public void setPitch(int pitch);
	

}
